package br.gov.fatec.calculando;

public interface Calculable {
	double calcularArea();
}
