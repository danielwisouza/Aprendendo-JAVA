package registro;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter


//peso maximo 1, cada prova tem pesos que variam entre 0.1, 0.3, etc
public class Prova {
	private double nota;
	private double peso;
	
	
	
	public Prova(double nota, double peso) {
		this.nota = nota;
		this.peso = peso;
	}
	
	//retorna a nota da prova, calculada de acordo com seu peso
	public double notaPeso() {
		return this.nota * this.peso;
	}
}
