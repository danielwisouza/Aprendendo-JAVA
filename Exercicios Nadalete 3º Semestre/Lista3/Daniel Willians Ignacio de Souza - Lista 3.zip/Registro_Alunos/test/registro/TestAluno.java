package registro;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class TestAluno {
	@Test
	public void cadastro() {
	// Verificando Lista Vazia
	Aluno cadatro1 = new Aluno("Daniel", "LP1", 123);
	//Altera��o Usuario
	cadatro1.alteraDados("Daniel Willias", "ED", 1234);
	assertEquals(cadatro1.getNome(), "Daniel Willias");
	assertEquals(cadatro1.getCurso(), "ED");
	assertEquals(cadatro1.getMatricula(), 1234);
	
	}
	@Test
	public void testeArray() {
		Aluno cadastro = new Aluno("Daniel", "LP2", 1234);
		assertArrayEquals(new Prova[4], cadastro.getNotas());
	}
	
	
	@Test
	public void darNota() {
		Aluno cadastro = new Aluno("Daniel", "LP2", 1234);
		assertEquals(0,cadastro.getMediaSemestre(),0);
	
		cadastro.darNota(new Prova(10, 2),(byte)0);
		cadastro.darNota(new Prova(10, 3),(byte)1);
		cadastro.darNota(new Prova(10, 2),(byte)2);
		cadastro.darNota(new Prova(10, 3),(byte)3);
		
		assertEquals(10,cadastro.getMediaSemestre(),10);
	}
}
	

