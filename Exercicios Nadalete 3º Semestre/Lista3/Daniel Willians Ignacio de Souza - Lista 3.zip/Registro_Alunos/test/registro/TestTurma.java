package registro;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TestTurma {

	@Test
	public void TurmaVazia() {
		Turma nova2 = new Turma("LP1",(short)5,"Primeiro");
		Aluno cadastro = new Aluno("Daniel", "LP2", 1234);
		nova2.cadastraAluno(cadastro);
		assertEquals(nova2.getNome(), "LP1");
	}
	
	@Test
	public void ExcluiAluno() {
		Turma nova2 = new Turma("LP1",(short)5,"Primeiro");
		Aluno cadastro = new Aluno("Daniel", "LP2", 1234);
		nova2.excluiAluno(cadastro.getNome());
	}
	
}
