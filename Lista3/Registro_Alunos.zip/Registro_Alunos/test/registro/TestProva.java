package registro;
import org.junit.Assert;
import org.junit.Test;

public class TestProva {
	
	//todo m�todo de teste deve ser public void
	// assert para fazer compara��es 
	// Representa que esse m�todo � de teste para poder rodar com jUnit (run as -> junit)
	// Coverage As para testar "colorindo" o c�digo nas partes executadas no teste
	
	@Test
	public void testeNotaPeso() {
		Prova cut = new Prova(6.0, 2.0);
		double valorNotaPeso = cut.notaPeso();		
		Assert.assertEquals(12.0, valorNotaPeso, 0.0);
	}

}
