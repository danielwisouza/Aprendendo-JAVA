package br.gov.fatec.sp.exercicio3;

public class EmpregadoMain {

	public static void main(String[] args) {
		Empregado empregado1 = new Empregado("Daniel", "Willains", 520.00);
		Empregado empregado2 = new Empregado("Thais", "Bitenccort", -1.33);
		
		Double salarioComAumento1 = empregado1.darAumento();
		Double salarioComAumento2 = empregado2.darAumento();
		
		System.out.println("EMPREGADO MAIN");
		System.out.println(empregado1.toString());
		System.out.println("Salario Anual: " + salarioComAumento1);
		System.out.println(empregado2.toString());
		System.out.println("Salario Anual: " + salarioComAumento2);
	}

}
