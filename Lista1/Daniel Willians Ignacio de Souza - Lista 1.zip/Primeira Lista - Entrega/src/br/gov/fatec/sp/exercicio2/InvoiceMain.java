package br.gov.fatec.sp.exercicio2;

public class InvoiceMain {
	public static void main(String[] args) {
		Invoice invoice = new Invoice(2l, "Notebook", 5, 1099.99);
		Invoice invoiceNegativa = new Invoice(1l, "Notebook", 5, -1099.99);
		
		Double valorRecalculado = invoice.getInvoiceAmount(invoice.getQuantidade(), invoice.getPrecoUnitario());

		System.out.println("INVOICE MAIN");
		System.out.println(invoice.toString());
		System.out.println("Novo Valor: " + valorRecalculado);
		System.out.println(invoiceNegativa.toString());
	}
}
