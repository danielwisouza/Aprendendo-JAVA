package br.gov.fatec.sp.exercicio1;

public class Carro {
	/* Um automovel cujo movimento resulta de mecanismo pr�prio, sem interven��o de for�a exterior
	 * Serve para transportar pessoas e objetos para v�rios lugares.
	 
	 * SUBSTANTIVOS: carro, roda, volante, motor, passageiro, combust�vel
	 * VERBOS: ligar, desligar, dirigir, buzinar, acenderFarol,
	 * 
	 * |  RODA  |		|   MOTOR   |
	 * |diametro|		|potencia   |
	 * |marca   |		|litragem   |
	 * |modelo  |		|numeroSerie|

	 * |    CARRO   |   | COMBUSTIVEL |                 
	 * |roda        |   |tipo         |
	 * |motor       |
	 * |combustivel |
	 * 
	
	 * Um carro possui roda, motor � abastecido com combustivel. Sem objeto carro, os outros objetos n�o existem
	 * 
	 * */
}
