package br.gov.fatec.sp.exercicio4;

public class Complex {

}
