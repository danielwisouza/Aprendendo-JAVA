package br.gov.fatec.sp.exercicio5;

public class DataMain {

	public static void main(String[] args) {
		Data data = new Data();
		System.out.println("Data do Sistema: " + data);
		Data data2 = new Data(24, 10, 1997);
		System.out.println("Data com par�metros " + data2);
		System.out.println("Data + 1: " + data2.avancar());
	}

}