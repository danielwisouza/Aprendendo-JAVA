package br.com.fatec.registro;

import br.com.fatec.escola.Aluno;
import br.com.fatec.escola.Prova;
//import br.com.fatec.escola.Turma;
//import br.com.fatec.escola.Prova;
import br.com.fatec.escola.Turma;

public class Main {

	public static void main(String[] args) {

		Turma Turma = new Turma(20);
		Aluno Aluno0 = new Aluno("Daniel",123, "LP2", criar());
		Aluno Aluno1 = new Aluno("Jonathan",124, "LP2", criar());
		Aluno Aluno2 = new Aluno("Henrique",125, "LP2", criar());
		Aluno Aluno3 = new Aluno("Lucas",126, "LP2", criar());
		Aluno Aluno4 = new Aluno("Isabella",127, "LP2", criar());
		Turma.incluir(Aluno0);
		Turma.incluir(Aluno1);
		Turma.incluir(Aluno2);
		Turma.incluir(Aluno3);
		Turma.incluir(Aluno4);
		Turma.alterar(Aluno1, 123, "LP1");
		Turma.consultarNome("Daniel");
		Turma.consultarMatricula(123);
		
		Turma.removerAluno("Daniel");
		Turma.listar();
}

	private static Prova[] criar() {
		Prova[] provas = new Prova[4];
		for (int i = 0; i < provas.length; i++) {	
		}
		return provas;
	}
}
