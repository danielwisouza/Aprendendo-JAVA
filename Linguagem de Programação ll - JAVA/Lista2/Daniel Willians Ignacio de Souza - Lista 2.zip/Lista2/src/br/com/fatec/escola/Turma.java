package br.com.fatec.escola;

import java.util.Arrays;

public class Turma {

	private Aluno[] alunos;
	private int quantidade;
	private int lugar;

	public Turma(int quantidade) {
		this.alunos = new Aluno[quantidade];
		this.quantidade = quantidade;
	}

	public void incluir(Aluno aluno) {
		if (lugar == alunos.length) {
			System.out.println("Esta turma encontra-se lotada");
		} else {
			alunos[lugar++] = aluno;
			System.out.println("Aluno foi cadastrado com sucesso");
		}
	}

	public void alterar(Aluno aluno, int matricula, String curso) {
		for (Aluno alunoNEW : alunos) {
			if (aluno.equals(alunoNEW)) {
				alunoNEW.setMatricula(matricula);
				alunoNEW.setCurso(curso);
				System.out.println("Aluno alterado com sucesso");
			}
		}
	}

	public void consultarNome(String nome) {
		for (int i = 0; i < lugar; i++) {
			if (alunos[i].getNome().equals(nome)) {
				System.out.println(alunos[i].toString());
			}
		}
	}

	public void consultarMatricula(int matricula) {
		for (int i = 0; i < lugar; i++) {
			if (alunos[i].getMatricula() == matricula) {
				System.out.println(alunos[i].toString());
			}
		}
	}

	public void listar() {
		String[] posicao = new String[lugar];
		for (int i = 0; i < lugar; i++) {
			posicao[i] = alunos[i].getNome();
		}
		Arrays.sort(posicao);
		for (int i = 0; i < posicao.length; i++) {
			System.out.println("Listar por ordem crescente: " + posicao[i]);
		}
	}

	public void removerAluno(String nome) {
		int t = 0;
		Aluno[] alunosRemove = new Aluno[quantidade];

		for (int i = 0; i < lugar; i++) {
			if (alunos[i].getNome().equals(nome)) {
				continue;
			} else {
				alunosRemove[t] = alunos[i];
				t++;
			}
			
		}
		lugar--;
		alunos = alunosRemove;
		System.out.println("Aluno removido");
	}

}
