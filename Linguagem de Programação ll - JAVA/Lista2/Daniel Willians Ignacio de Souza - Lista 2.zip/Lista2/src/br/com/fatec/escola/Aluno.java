package br.com.fatec.escola;

public class Aluno {

	private String nome;
	private int matricula;
	private String curso;
	private Prova[] provas = new Prova[4];

	public Aluno(String nome, int matricula, String curso, Prova[] provas) {
		this.setNome(nome);
		this.setMatricula(matricula);
		this.setCurso(curso);
		this.setProvas(provas);
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getMatricula() {
		return matricula;
	}

	public void setMatricula(int matricula) {
		this.matricula = matricula;
	}

	public String getCurso() {
		return curso;
	}

	public void setCurso(String curso) {
		this.curso = curso;
	}

	public Prova[] getProvas() {
		return provas;
	}

	public void setProvas(Prova[] provas) {
		this.provas = provas;
	}
}