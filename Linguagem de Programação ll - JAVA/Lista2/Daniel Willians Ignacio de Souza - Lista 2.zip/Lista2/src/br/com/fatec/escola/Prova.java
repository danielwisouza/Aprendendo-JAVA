package br.com.fatec.escola;

public class Prova {
	private Double valor;
	private Double peso;

	public Prova(java.lang.Double valor, java.lang.Double peso) {
	    this.setValor(valor);
		this.setPeso(peso);
	}

	public Double getValor() {
		return valor;
	}

	public void setValor(Double valor) {
		this.valor = valor;
	}

	public Double getPeso() {
		return peso;
	}

	public void setPeso(Double peso) {
		this.peso = peso;
	}
}
